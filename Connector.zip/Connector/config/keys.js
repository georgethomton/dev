module.exports = {
  mongoURI: "mongodb://sid:sid@ds241578.mlab.com:41578/devconnector",
  secretOrKey: "secret"
};
